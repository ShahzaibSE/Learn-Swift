import Cocoa

var str = "Hello, playground"

//A Saturday brain teaser : If we list all the natural numbers below 10 that are multiples of 3 or 5, we get 3, 5, 6 and 9. The sum of these multiples is 23. Find the sum of all the multiples of 3 or 5 below 1000. And, please don’t use Google to find the solution.

var multiples: Array<Int> = Array<Int>()
//for num in 1..<10 {   // Uncomment code to verify.
for num in 1..<1000 {
    if num % 3 == 0 {
        // multipleSum3 += num
        multiples.append(num)
    }else if num % 5 == 0 {
        // multipleSum5 += num
        multiples.append(num)
    }
}
// print("Sum of multiple of 3: \(multipleSum3)")
// print("Sum of multiple of 5: \(multipleSum5)")
print("Multiples of 3 and 5: \(multiples)")
// multiples
var multipleSum = multiples.reduce(0) { (total, num) in
    return total + num
}

print("Sum of multiple of 3 and 5: \(multipleSum)")
